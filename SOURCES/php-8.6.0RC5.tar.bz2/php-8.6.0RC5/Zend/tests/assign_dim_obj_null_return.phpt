--TEST--
Various null return conditions of dim/obj assignments
--FILE--
<?php

function test() {
    $array = [PHP_INT_MAX => 42];
    $true = true;

    try {
        var_dump($array[] = 123);
    } catch (Throwable $e) {
        echo $e::class, ': ', $e->getMessage(), "\n";
    }

    try {
        var_dump($array[[]] = 123);
    } catch (Throwable $e) {
        echo $e::class, ': ', $e->getMessage(), "\n";
    }

    try {
        var_dump($array[new stdClass] = 123);
    } catch (Throwable $e) {
        echo $e::class, ': ', $e->getMessage(), "\n";
    }

    try {
        var_dump($true[123] = 456);
    } catch (Throwable $e) {
        echo $e::class, ': ', $e->getMessage(), "\n";
    }

    try {
        var_dump($array[] += 123);
    } catch (Throwable $e) {
        echo $e::class, ': ', $e->getMessage(), "\n";
    }

    try {
        var_dump($array[[]] += 123);
    } catch (Throwable $e) {
        echo $e::class, ': ', $e->getMessage(), "\n";
    }

    try {
        var_dump($array[new stdClass] += 123);
    } catch (Throwable $e) {
        echo $e::class, ': ', $e->getMessage(), "\n";
    }

    try {
        var_dump($true[123] += 456);
    } catch (Throwable $e) {
        echo $e::class, ': ', $e->getMessage(), "\n";
    }

    try {
        var_dump($true->foo = 123);
    } catch (Throwable $e) {
        echo $e::class, ': ', $e->getMessage(), "\n";
    }
    try {
        var_dump($true->foo += 123);
    } catch (Throwable $e) {
        echo $e::class, ': ', $e->getMessage(), "\n";
    }
}

test();

?>
--EXPECT--
Error: Cannot add element to the array as the next element is already occupied
TypeError: Cannot access offset of type array on array
TypeError: Cannot access offset of type stdClass on array
Error: Cannot use a scalar value as an array
Error: Cannot add element to the array as the next element is already occupied
TypeError: Cannot access offset of type array on array
TypeError: Cannot access offset of type stdClass on array
Error: Cannot use a scalar value as an array
Error: Attempt to assign property "foo" on true
Error: Attempt to assign property "foo" on true
