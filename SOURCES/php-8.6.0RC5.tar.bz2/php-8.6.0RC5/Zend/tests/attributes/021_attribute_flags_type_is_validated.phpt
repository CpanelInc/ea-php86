--TEST--
Attribute flags type is validated.
--FILE--
<?php

#[Attribute("foo")]
class A1 { }

#[A1]
class Foo {}

try {
    (new ReflectionClass(Foo::class))->getAttributes()[0]->newInstance();
} catch (Throwable $e) {
    echo $e::class, ': ', $e->getMessage(), "\n";
}

?>
--EXPECT--
Error: Attribute::__construct(): Argument #1 ($flags) must be of type int, string given
